Movie Recommender System
– System suggests similar movies which have a higher probability of being liked based on the movie input by user, used Cosine Similarity.
– Created using Flask, NumPy, Pandas, scikit-learn & hosted it on localhost webpapp using HTML, CSS, JavaScript.
– Used SQLAlchemy as database management & using API shows posters of movies from TMDB
